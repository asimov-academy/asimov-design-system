# Asimov · design system de email Black Friday

A estrutura do design system Asimov nas cores da Black Friday 2026: preto, laranja #ff6e14, luz teal e Rethink Sans. O visual não escreve "Black Friday"; quem fala da Black é o texto.

Guia visual: https://asimov-design-system.vercel.app/emails/design-system-black/index.html

## O que tem aqui

- `design-system.json`: variantes, componentes, cores, tipografia e variáveis, para código.
- `<variante>/casca.html`: o documento do email (head, estilos, container de 600px). O conteúdo entra em `{{linhas}}`.
- `<variante>/componentes/`: uma peça por arquivo. **Linhas** vão direto na casca; **blocos** vão dentro da linha `corpo`, no lugar de `{{blocos}}`.
- `<variante>/catalogo.html`: todas as peças da variante, empilhadas. Abra no navegador para ver tudo de uma vez.
- `exemplos/`: emails prontos feitos com este sistema.
- `img/`: as imagens usadas.

Variantes:

- `escuro/`: Tema escuro
- `claro/`: Tema claro

As peças são iguais em todas as variantes; só mudam cores e imagens.

## Como montar um email

1. Escolha a variante e abra `casca.html`.
2. Troque `{{assunto}}` e `{{preheader}}`.
3. Em `{{linhas}}`, cole as linhas na ordem do email.
4. Na linha `corpo`, troque `{{blocos}}` pelos blocos de texto: parágrafos, botões, lista, assinatura, PS.
5. Troque os textos de exemplo (lorem ipsum) pelos reais e preencha as variáveis de link.

Receitas comuns:

- **Conversacional:** `capa` → `corpo`
- **Com título:** `topo` → `titulo` → `corpo` → `destaque` → `corpo` → `cta`

## Linhas

| Arquivo | Peça | Quando usar |
|---|---|---|
| `01-linha-capa.html` | Capa | Topo dos emails conversacionais: a luz da campanha e só o ASIMOV, em 600x150. |
| `02-linha-topo.html` | Cartão de topo | Topo dos emails com título: capa e título com uma expressão em laranja. |
| `03-linha-titulo.html` | Título de seção | Sobretítulo e título que abrem um trecho do email. [[...]] no título vira laranja. |
| `04-linha-corpo.html` | Corpo | O texto do email. Recebe os blocos em {{blocos}}. |
| `05-linha-destaque.html` | Superfície com luz | Uma ideia em evidência no meio do texto. |
| `06-linha-destaque-selos.html` | Superfície com selos | A superfície com selos de público (aluno Formação, Trilha, Anual). |
| `07-linha-cta.html` | Cartão de CTA | Fechamento com a ação principal, com a luz da Black por baixo. |
| `08-linha-ingresso.html` | Ingresso da live | Opcional de campanha: data e horário da live como ingresso. |
| `09-linha-contagem.html` | Contagem regressiva | Opcional de campanha: estática; para andar, troque por um GIF de contador. |
| `10-linha-pilula.html` | Pílula ao vivo | Opcional de campanha: data e hora da live em destaque. |
| `11-linha-faixa.html` | Faixa da campanha | Opcional de campanha: a faixa laranja com texto, de ponta a ponta. |
| `12-linha-faixa-espectro.html` | Faixa espectro | Opcional de campanha: a faixa com o degradê teal, vermelho, teal. |

## Blocos

| Arquivo | Peça | Quando usar |
|---|---|---|
| `13-bloco-paragrafo.html` | Parágrafo | Todo o texto corrido. Frases curtas, um parágrafo por ideia. |
| `14-bloco-botao.html` | Botão chamativo | Padrão quando a ação é o objetivo do email (cadastro, compra). |
| `15-bloco-botao-discreto.html` | Botão discreto | Padrão quando o botão é um convite (relacionamento, conteúdo). Não misture com o chamativo. |
| `16-bloco-lista.html` | Lista | Itens curtos e paralelos. |
| `17-bloco-assinatura.html` | Assinatura | Quem assina o email. O cargo é opcional. |
| `18-bloco-ps.html` | PS | Pós-escrito no fim do texto. |
| `19-bloco-botao-a-degrade.html` | Botão A · Degradê | Pílula em degradê vertical, caixa alta. A mais próxima das peças da campanha: guarde para emails de venda direta. |
| `20-bloco-botao-b-solido.html` | Botão B · Sólido | Laranja chapado, cantos de 12px, texto normal. Mais sóbrio, bom para emails conversacionais. |
| `21-bloco-botao-c-contorno.html` | Botão C · Contorno | Só a borda laranja. Para uma segunda ação, ou quando o email já tem muita cor. |
| `22-bloco-botao-e-brasa.html` | Botão E · Brasa | Fundo laranja bem escuro e texto pêssego (no claro, pêssego claro e texto terracota). Discreto e quente. |
| `23-bloco-botao-f-borda-espectro.html` | Botão F · Borda espectro | Contorno com o degradê teal, vermelho, teal da faixa. Onde não há degradê, a borda fica laranja. |
| `24-bloco-botao-h-compacto.html` | Botão H · Compacto | Pílula menor, 13px. Para ações secundárias no meio do texto. |
| `25-bloco-botao-i-link.html` | Botão I · Link | Texto laranja sublinhado com seta. Para quando o botão seria demais. |
| `26-bloco-botao-j-largura-total.html` | Botão J · Largura total | Degradê ocupando a coluna inteira. Para o fim de emails curtos e para o mobile. |

## Variáveis

| Variável | O que é |
|---|---|
| `{{assunto}}` | Assunto do email (vai no <title>). |
| `{{preheader}}` | Texto de prévia que aparece ao lado do assunto na caixa de entrada. |
| `{{linhas}}` | Na casca: onde entram as linhas, em sequência. |
| `{{blocos}}` | Na linha 'corpo': onde entram os blocos de texto, em sequência. |
| `{{link_cta}}` | Destino dos botões. |
| `{{link_descadastro}}` | Link de cancelar inscrição (obrigatório). |
| `{{link_youtube}}` | Rodapé. |
| `{{link_instagram}}` | Rodapé. |
| `{{link_linkedin}}` | Rodapé. |
| `{{endereco}}` | Endereço da empresa no rodapé (obrigatório). |

## Regras

- Troque só textos e links. Tabelas, estilos inline, larguras e os blocos `<!--[if mso]>` (Outlook) precisam ficar como estão.
- Um botão por ideia. Rótulos curtos, com verbo.
- Imagens: já apontam para `https://img.asimov.academy/email/black/v1/`, uma pasta que nunca muda. Para hospedar em outro lugar, suba a pasta `img/` e troque esse prefixo.
- Teste no Gmail, no Outlook e no celular antes de disparar.
- A casca deste sistema já traz o fio de cor do topo, a faixa ASIMOV e o rodapé. Não há linha de rodapé.
- Peças de campanha (ingresso, contagem, pílula, faixas) são opcionais. Use com parcimônia.

## Com uma LLM

Entregue à LLM a casca, os componentes da variante e a copy, e peça algo como:

> Monte um email com a casca e os componentes abaixo. Use só esses componentes, na ordem que fizer
> sentido para a copy. Troque apenas os textos de exemplo pela copy. Não altere tabelas, estilos,
> atributos, comentários `<!--[if mso]>` nem variáveis `{{...}}`. Responda só com o HTML final.

Se a sua aplicação montar o email por código, a LLM pode devolver só a lista de peças e textos, e o
código junta os arquivos. É mais previsível do que pedir o HTML inteiro.
