# Asimov · design system de email Cadence

A chuva de luz do Cadence Rain com cara de workspace: trilho numerado em mono, janela de editor e CTA como tecla teal.

Guia visual: https://asimov-design-system.vercel.app/emails/design-system-cadence/index.html

## O que tem aqui

- `design-system.json`: variantes, componentes, cores, tipografia e variáveis, para código.
- `<variante>/casca.html`: o documento do email (head, estilos, container de 600px). O conteúdo entra em `{{linhas}}`.
- `<variante>/componentes/`: uma peça por arquivo. **Linhas** vão direto na casca; **blocos** vão dentro da linha `corpo`, no lugar de `{{blocos}}`.
- `<variante>/catalogo.html`: todas as peças da variante, empilhadas. Abra no navegador para ver tudo de uma vez.
- `exemplos/`: emails prontos feitos com este sistema.
- `img/`: as imagens usadas.

Variantes:

- `escuro/`: Tema escuro
- `claro/`: Tema claro

As peças são iguais em todas as variantes; só mudam cores e imagens.

## Como montar um email

1. Escolha a variante e abra `casca.html`.
2. Troque `{{assunto}}` e `{{preheader}}`.
3. Em `{{linhas}}`, cole as linhas na ordem do email.
4. Na linha `corpo`, troque `{{blocos}}` pelos blocos de texto: parágrafos, botões, lista, assinatura, PS.
5. Troque os textos de exemplo (lorem ipsum) pelos reais e preencha as variáveis de link.

Receitas comuns:

- **Conversacional:** `capa` → `corpo` → `rodape`
- **Com título:** `hero` → `passo` → `passo` → `passo-final` → `proximo-passo` → `rodape`

## Linhas

| Arquivo | Peça | Quando usar |
|---|---|---|
| `01-linha-capa.html` | Capa | Topo dos emails conversacionais: a chuva de luz numa faixa de 600x150. |
| `02-linha-hero.html` | Cabeçalho | Topo dos emails com título: chuva de luz, manchete e ficha técnica. |
| `03-linha-passo.html` | Passo do trilho | Um trecho numerado do texto: índice em mono, fio e título. Troque o número (01, 02...). |
| `04-linha-passo-final.html` | Último passo | Fecha o trilho: vem logo depois de um passo, sem espaço acima. |
| `05-linha-corpo.html` | Corpo | O texto do email. Recebe os blocos em {{blocos}}. |
| `06-linha-proximo-passo.html` | Próximo passo | Fechamento com a ação: rótulo em mono e a tecla teal. |
| `07-linha-rodape.html` | Rodapé | Endereço, redes e descadastro. Obrigatório. |

## Blocos

| Arquivo | Peça | Quando usar |
|---|---|---|
| `08-bloco-paragrafo.html` | Parágrafo | Todo o texto corrido. Frases curtas, um parágrafo por ideia. |
| `09-bloco-botao.html` | Botão | A ação do email: a tecla teal, alinhada ao texto. |
| `10-bloco-janela.html` | Janela de editor | A frase que merece destaque, como um arquivo aberto. |
| `11-bloco-lista.html` | Lista numerada | Itens curtos e paralelos, numerados em mono. |
| `12-bloco-assinatura.html` | Assinatura | Quem assina o email. O cargo é opcional. |
| `13-bloco-ps.html` | PS | Pós-escrito no fim do texto. |

## Variáveis

| Variável | O que é |
|---|---|
| `{{assunto}}` | Assunto do email (vai no <title>). |
| `{{preheader}}` | Texto de prévia que aparece ao lado do assunto na caixa de entrada. |
| `{{linhas}}` | Na casca: onde entram as linhas, em sequência. |
| `{{blocos}}` | Na linha 'corpo': onde entram os blocos de texto, em sequência. |
| `{{link_cta}}` | Destino dos botões. |
| `{{link_descadastro}}` | Link de cancelar inscrição (obrigatório). |
| `{{link_youtube}}` | Rodapé. |
| `{{link_instagram}}` | Rodapé. |
| `{{link_linkedin}}` | Rodapé. |
| `{{endereco}}` | Endereço da empresa no rodapé (obrigatório). |

## Regras

- Troque só textos e links. Tabelas, estilos inline, larguras e os blocos `<!--[if mso]>` (Outlook) precisam ficar como estão.
- Um botão por ideia. Rótulos curtos, com verbo.
- Imagens: já apontam para `https://img.asimov.academy/email/cadence/v1/`, uma pasta que nunca muda. Para hospedar em outro lugar, suba a pasta `img/` e troque esse prefixo.
- Teste no Gmail, no Outlook e no celular antes de disparar.


## Com uma LLM

Entregue à LLM a casca, os componentes da variante e a copy, e peça algo como:

> Monte um email com a casca e os componentes abaixo. Use só esses componentes, na ordem que fizer
> sentido para a copy. Troque apenas os textos de exemplo pela copy. Não altere tabelas, estilos,
> atributos, comentários `<!--[if mso]>` nem variáveis `{{...}}`. Responda só com o HTML final.

Se a sua aplicação montar o email por código, a LLM pode devolver só a lista de peças e textos, e o
código junta os arquivos. É mais previsível do que pedir o HTML inteiro.
