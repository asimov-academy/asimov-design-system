# Asimov · design system de email Aura

O design system de email principal da Asimov, na linguagem do Overview: a paisagem Aura, superfícies com brilho e o teal da marca.

Guia visual: https://asimov-design-system.vercel.app/emails/design-system/index.html

## O que tem aqui

- `design-system.json`: variantes, componentes, cores, tipografia e variáveis, para código.
- `<variante>/casca.html`: o documento do email (head, estilos, container de 600px). O conteúdo entra em `{{linhas}}`.
- `<variante>/componentes/`: uma peça por arquivo. **Linhas** vão direto na casca; **blocos** vão dentro da linha `corpo`, no lugar de `{{blocos}}`.
- `<variante>/catalogo.html`: todas as peças da variante, empilhadas. Abra no navegador para ver tudo de uma vez.
- `exemplos/`: emails prontos feitos com este sistema.
- `img/`: as imagens usadas.

Variantes:

- `escuro/`: Tema escuro
- `claro/`: Tema claro

As peças são iguais em todas as variantes; só mudam cores e imagens.

## Como montar um email

1. Escolha a variante e abra `casca.html`.
2. Troque `{{assunto}}` e `{{preheader}}`.
3. Em `{{linhas}}`, cole as linhas na ordem do email.
4. Na linha `corpo`, troque `{{blocos}}` pelos blocos de texto: parágrafos, botões, lista, assinatura, PS.
5. Troque os textos de exemplo (lorem ipsum) pelos reais e preencha as variáveis de link.

Receitas comuns:

- **Conversacional:** `capa` → `corpo` → `divisor` → `rodape`
- **Com título:** `hero` → `titulo` → `corpo` → `destaque` → `corpo` → `cta` → `divisor` → `rodape`

## Linhas

| Arquivo | Peça | Quando usar |
|---|---|---|
| `01-linha-capa.html` | Capa | Topo dos emails conversacionais: a paisagem Aura numa faixa de 600x150. |
| `02-linha-hero.html` | Hero | Topo dos emails com título: paisagem, pílula, título e subtítulo. |
| `03-linha-titulo.html` | Título de seção | Sobretítulo e título que abrem um trecho do email. |
| `04-linha-corpo.html` | Corpo | O texto do email. Recebe os blocos em {{blocos}}. |
| `05-linha-destaque.html` | Cartão de destaque | Uma ideia em evidência no meio do texto: ícone, sobretítulo, título e texto. |
| `06-linha-faixa.html` | Faixa de paisagem | Respiro visual entre trechos longos. |
| `07-linha-cta.html` | Cartão de CTA | Fechamento com a ação principal: faixa, título, botão e nota. |
| `08-linha-divisor.html` | Divisor | Separa o conteúdo do rodapé. |
| `09-linha-rodape.html` | Rodapé | Logo, redes, endereço e descadastro. Obrigatório. |

## Blocos

| Arquivo | Peça | Quando usar |
|---|---|---|
| `10-bloco-paragrafo.html` | Parágrafo | Todo o texto corrido. Frases curtas, um parágrafo por ideia. |
| `11-bloco-botao.html` | Botão principal | A ação do email, no meio ou no fim do texto. |
| `12-bloco-botao-secundario.html` | Botão secundário | Uma segunda ação, menos importante que a principal. |
| `13-bloco-link.html` | Link com seta | Ação discreta, quando um botão seria demais. |
| `14-bloco-lista.html` | Lista | Itens curtos e paralelos. |
| `15-bloco-assinatura.html` | Assinatura | Quem assina o email. O cargo é opcional. |
| `16-bloco-ps.html` | PS | Pós-escrito no fim do texto. |

## Variáveis

| Variável | O que é |
|---|---|
| `{{assunto}}` | Assunto do email (vai no <title>). |
| `{{preheader}}` | Texto de prévia que aparece ao lado do assunto na caixa de entrada. |
| `{{linhas}}` | Na casca: onde entram as linhas, em sequência. |
| `{{blocos}}` | Na linha 'corpo': onde entram os blocos de texto, em sequência. |
| `{{link_cta}}` | Destino dos botões. |
| `{{link_descadastro}}` | Link de cancelar inscrição (obrigatório). |
| `{{link_youtube}}` | Rodapé. |
| `{{link_instagram}}` | Rodapé. |
| `{{link_linkedin}}` | Rodapé. |
| `{{endereco}}` | Endereço da empresa no rodapé (obrigatório). |

## Regras

- Troque só textos e links. Tabelas, estilos inline, larguras e os blocos `<!--[if mso]>` (Outlook) precisam ficar como estão.
- Um botão por ideia. Rótulos curtos, com verbo.
- Imagens: já apontam para `https://asimov-design-system.vercel.app/emails/design-system/img/`. Para hospedar em outro lugar, suba a pasta `img/` e troque esse prefixo.
- Teste no Gmail, no Outlook e no celular antes de disparar.


## Com uma LLM

Entregue à LLM a casca, os componentes da variante e a copy, e peça algo como:

> Monte um email com a casca e os componentes abaixo. Use só esses componentes, na ordem que fizer
> sentido para a copy. Troque apenas os textos de exemplo pela copy. Não altere tabelas, estilos,
> atributos, comentários `<!--[if mso]>` nem variáveis `{{...}}`. Responda só com o HTML final.

Se a sua aplicação montar o email por código, a LLM pode devolver só a lista de peças e textos, e o
código junta os arquivos. É mais previsível do que pedir o HTML inteiro.
