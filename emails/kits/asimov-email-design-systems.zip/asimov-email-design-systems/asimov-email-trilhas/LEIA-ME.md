# Asimov · design system de email Trilhas

Um halo de luz na cor de cada formação ou trilha. A paleta (dark, accent, light, glow) vem do assets/themes.js e vira faixa, pontos e citação.

Guia visual: https://asimov-design-system.vercel.app/emails/design-system-trilhas/index.html

## O que tem aqui

- `design-system.json`: variantes, componentes, cores, tipografia e variáveis, para código.
- `<variante>/casca.html`: o documento do email (head, estilos, container de 600px). O conteúdo entra em `{{linhas}}`.
- `<variante>/componentes/`: uma peça por arquivo. **Linhas** vão direto na casca; **blocos** vão dentro da linha `corpo`, no lugar de `{{blocos}}`.
- `<variante>/catalogo.html`: todas as peças da variante, empilhadas. Abra no navegador para ver tudo de uma vez.
- `exemplos/`: emails prontos feitos com este sistema.
- `img/`: as imagens usadas.

Variantes:

- `teal-escuro/`: Teal Asimov (Asimov Academy), tema escuro
- `teal-claro/`: Teal Asimov (Asimov Academy), tema claro
- `engenheiro-ia-escuro/`: Engenheiro de IA (Formação), tema escuro
- `engenheiro-ia-claro/`: Engenheiro de IA (Formação), tema claro
- `analista-dados-escuro/`: Analista de Dados (Formação), tema escuro
- `analista-dados-claro/`: Analista de Dados (Formação), tema claro
- `ai-designer-escuro/`: AI Designer (Formação), tema escuro
- `ai-designer-claro/`: AI Designer (Formação), tema claro
- `n8n-escuro/`: Automações n8n (Trilha), tema escuro
- `n8n-claro/`: Automações n8n (Trilha), tema claro

As peças são iguais em todas as variantes; só mudam cores e imagens.

## Como montar um email

1. Escolha a variante e abra `casca.html`.
2. Troque `{{assunto}}` e `{{preheader}}`.
3. Em `{{linhas}}`, cole as linhas na ordem do email.
4. Na linha `corpo`, troque `{{blocos}}` pelos blocos de texto: parágrafos, botões, lista, assinatura, PS.
5. Troque os textos de exemplo (lorem ipsum) pelos reais e preencha as variáveis de link.

Receitas comuns:

- **Conversacional:** `topo` → `corpo` → `rodape`
- **Com título:** `hero` → `ficha` → `titulo` → `corpo` → `marcos` → `corpo` → `citacao` → `cta` → `rodape`

## Linhas

| Arquivo | Peça | Quando usar |
|---|---|---|
| `01-linha-topo.html` | Topo | Topo dos emails conversacionais: logo e a faixa com a paleta da trilha. |
| `02-linha-hero.html` | Halo | Topo dos emails com título: o halo na cor da trilha, com o título dentro do anel. |
| `03-linha-ficha.html` | Ficha da trilha | Nome da formação ou trilha, pontos e faixa do espectro. Logo abaixo do halo. |
| `04-linha-titulo.html` | Título de seção | Sobretítulo e título que abrem um trecho do email. |
| `05-linha-corpo.html` | Corpo | O texto do email. Recebe os blocos em {{blocos}}. |
| `06-linha-marcos.html` | Marcos | Três etapas em colunas, com números na cor da trilha. |
| `07-linha-citacao.html` | Citação | Uma frase de destaque por email, ao lado da barra de espectro. |
| `08-linha-cta.html` | CTA no halo | Fechamento com a ação: título e o botão dentro de um halo menor. |
| `09-linha-rodape.html` | Rodapé | Pontos da paleta, redes, endereço e descadastro. Obrigatório. |

## Blocos

| Arquivo | Peça | Quando usar |
|---|---|---|
| `10-bloco-paragrafo.html` | Parágrafo | Todo o texto corrido. Frases curtas, um parágrafo por ideia. |
| `11-bloco-botao.html` | Botão | A ação do email: pílula na cor da trilha, centralizada. |
| `12-bloco-lista.html` | Lista | Itens curtos e paralelos. |
| `13-bloco-assinatura.html` | Assinatura | Quem assina o email. O cargo é opcional. |
| `14-bloco-ps.html` | PS | Pós-escrito no fim do texto. |

## Variáveis

| Variável | O que é |
|---|---|
| `{{assunto}}` | Assunto do email (vai no <title>). |
| `{{preheader}}` | Texto de prévia que aparece ao lado do assunto na caixa de entrada. |
| `{{linhas}}` | Na casca: onde entram as linhas, em sequência. |
| `{{blocos}}` | Na linha 'corpo': onde entram os blocos de texto, em sequência. |
| `{{link_cta}}` | Destino dos botões. |
| `{{link_descadastro}}` | Link de cancelar inscrição (obrigatório). |
| `{{link_youtube}}` | Rodapé. |
| `{{link_instagram}}` | Rodapé. |
| `{{link_linkedin}}` | Rodapé. |
| `{{endereco}}` | Endereço da empresa no rodapé (obrigatório). |

## Regras

- Troque só textos e links. Tabelas, estilos inline, larguras e os blocos `<!--[if mso]>` (Outlook) precisam ficar como estão.
- Um botão por ideia. Rótulos curtos, com verbo.
- Imagens: já apontam para `https://asimov-design-system.vercel.app/emails/design-system-trilhas/img/`. Para hospedar em outro lugar, suba a pasta `img/` e troque esse prefixo.
- Teste no Gmail, no Outlook e no celular antes de disparar.
- Escolha a variante pela formação ou trilha do público. Para a marca Asimov em geral, use teal.

## Com uma LLM

Entregue à LLM a casca, os componentes da variante e a copy, e peça algo como:

> Monte um email com a casca e os componentes abaixo. Use só esses componentes, na ordem que fizer
> sentido para a copy. Troque apenas os textos de exemplo pela copy. Não altere tabelas, estilos,
> atributos, comentários `<!--[if mso]>` nem variáveis `{{...}}`. Responda só com o HTML final.

Se a sua aplicação montar o email por código, a LLM pode devolver só a lista de peças e textos, e o
código junta os arquivos. É mais previsível do que pedir o HTML inteiro.
